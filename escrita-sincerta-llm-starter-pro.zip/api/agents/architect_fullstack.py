import os, requests

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
MODEL = os.getenv("ARCH_MODEL", "qwen2.5:7b")

PROMPT = (
  "Você é arquiteto fullstack. Entregue arquitetura alvo local-first com camadas, pastas e escolhas de libs para React, Vue, Next, Node, Python (FastAPI), e Flutter. "
  "Inclua comandos de criação (npx, pip, flutter create) e anotações de segurança e testes. "
  "Formato: Contexto → Arquitetura → Passos de criação → Observações de deploy local."
)

def ollama_chat(messages):
    r = requests.post(f"{OLLAMA_URL}/api/chat", json={"model": MODEL, "messages": messages, "stream": False}, timeout=120)
    r.raise_for_status()
    return r.json().get("message", {}).get("content", "")

def agent(message: str, history: list[dict]):
    sys = {"role":"system","content":PROMPT}
    msgs = [sys] + history + [{"role":"user","content": message}]
    out = ollama_chat(msgs)
    return {"reply": out}
