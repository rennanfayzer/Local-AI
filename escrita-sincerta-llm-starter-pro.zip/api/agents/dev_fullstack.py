import os, requests

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
MODEL = os.getenv("DEV_MODEL", "qwen2.5:7b")

def ollama_chat(messages):
    r = requests.post(f"{OLLAMA_URL}/api/chat", json={"model": MODEL, "messages": messages, "stream": False}, timeout=120)
    r.raise_for_status()
    return r.json().get("message", {}).get("content", "")

def agent(message: str, history: list[dict]):
    system = {"role":"system","content":"Você é a 'chegada' dev fullstack. Seja direto, técnico e honesto."}
    msgs = [system] + history + [{"role":"user","content":message}]
    out = ollama_chat(msgs)
    return {"reply": out}
