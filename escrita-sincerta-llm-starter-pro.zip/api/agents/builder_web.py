import os, requests, base64

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
MODEL = os.getenv("BUILD_MODEL", "qwen2.5:7b")

PROMPT = (
  "Você é gerador de scaffolds. Dado um framework (react|next|vue|node|fastapi|flutter) e um nome, "
  "gere os comandos para criar o projeto e a estrutura inicial de arquivos com conteúdo mínimo funcional. "
  "Sempre entregar blocos de código prontos para colar."
)

def ollama_chat(messages):
    r = requests.post(f"{OLLAMA_URL}/api/chat", json={"model": MODEL, "messages": messages, "stream": False}, timeout=120)
    r.raise_for_status()
    return r.json().get("message", {}).get("content", "")

def agent(message: str, history: list[dict]):
    sys = {"role":"system","content":PROMPT}
    msgs = [sys] + history + [{"role":"user","content": message}]
    out = ollama_chat(msgs)
    return {"reply": out}
