from .dev_fullstack import agent as dev_agent
from .reflexivo import agent as reflexivo_agent
from .ideator_saas import agent as ideator_agent
from .architect_fullstack import agent as architect_agent
from .builder_web import agent as builder_agent

REGISTRY = {
    "dev_fullstack": dev_agent,
    "reflexivo": reflexivo_agent,
    "ideator": ideator_agent,
    "architect": architect_agent,
    "builder": builder_agent,
}

def run_agent(name: str, message: str, history: list[dict]):
    agent = REGISTRY.get(name)
    if not agent:
        return {"error": f"agente '{name}' não encontrado"}
    return agent(message=message, history=history)
