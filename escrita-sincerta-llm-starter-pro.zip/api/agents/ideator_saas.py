import os, requests, json

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
MODEL = os.getenv("IDEA_MODEL", "qwen2.5:7b")

PROMPT = (
  "Você é um gerador de ideias de SaaS 100% pragmático. "
  "Para cada ideia: gere ICP, dor, proposta de valor, canais, MVP técnico local (React/Next/Vue/Node/Python/Flutter), "
  "modelo de monetização, riscos, primeiros 3 experimentos e métricas (AARRR). "
  "Formato curto em JSON.
"
)

def ollama_chat(messages):
    r = requests.post(f"{OLLAMA_URL}/api/chat", json={"model": MODEL, "messages": messages, "stream": False}, timeout=120)
    r.raise_for_status()
    return r.json().get("message", {}).get("content", "")

def agent(message: str, history: list[dict]):
    sys = {"role":"system","content":PROMPT}
    msgs = [sys] + history + [{"role":"user","content": message}]
    out = ollama_chat(msgs)
    try:
        data = json.loads(out)
    except Exception:
        data = {"raw": out}
    return {"reply": data}
