import platform

def info():
    return {'platform': platform.platform()}
