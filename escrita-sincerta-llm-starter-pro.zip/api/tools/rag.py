# Placeholder de RAG. Em próxima etapa conectar embeddings locais e pgvector.
def ingest_path(path: str) -> int:
    import glob
    files = [f for f in glob.glob(f"{path}/**/*", recursive=True) if any(f.endswith(ext) for ext in [".md",".txt",".html"])]
    return len(files)

def query_vectors(q: str, k: int = 5):
    return []

