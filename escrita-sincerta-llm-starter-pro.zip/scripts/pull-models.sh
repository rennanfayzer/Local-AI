#!/usr/bin/env bash
set -euo pipefail
MODELS=${OLLAMA_MODELS:-"qwen2.5:7b,phi3:3.8b"}
IFS=',' read -ra arr <<< "$MODELS"
for m in "${arr[@]}"; do
  echo "Baixando modelo: $m"
  curl -sS http://localhost:11434/api/pull -d '{"name":"'"$m"'"}' || true
  echo
done
