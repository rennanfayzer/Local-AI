# Escrita Sincerta LLM — Starter Local

## Rodar
1. Copie `.env.example` para `.env` e ajuste portas/modelos.
2. `docker compose up -d --build`
3. Acesse Open WebUI: http://localhost:3000
4. `make pull` para baixar modelos no Ollama
5. `make ingest` para indexar `data/docs` (opcional)
6. Teste a API: `curl http://localhost:8000/health`

## Estrutura
- `api/` FastAPI + agentes
- `data/docs` base de arquivos para RAG
- `data/vectors` volume do Postgres (pgvector)
