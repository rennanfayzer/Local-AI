import os, requests

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
MODEL = os.getenv("REFLEX_MODEL", "phi3:3.8b")

def ollama_chat(messages):
    r = requests.post(f"{OLLAMA_URL}/api/chat", json={"model": MODEL, "messages": messages, "stream": False}, timeout=120)
    r.raise_for_status()
    return r.json().get("message", {}).get("content", "")

def agent(message: str, history: list[dict]):
    system = {"role":"system","content":"Você é um espelho honesto do usuário. Reflita com empatia e proponha passos práticos."}
    msgs = [system] + history + [{"role":"user","content":message}]
    out = ollama_chat(msgs)
    return {"reply": out}
