from fastapi import FastAPI, Body
from pydantic import BaseModel
import os, requests

app = FastAPI(title="Escrita Sincerta API")

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
DEV_MODEL = os.getenv("DEV_MODEL", "qwen2.5:7b")
REFLEX_MODEL = os.getenv("REFLEX_MODEL", "phi3:3.8b")

class ChatReq(BaseModel):
    agent: str = "dev_fullstack"
    message: str
    history: list[dict] = []

def ollama_chat(model: str, messages: list[dict]) -> str:
    r = requests.post(f"{OLLAMA_URL}/api/chat", json={"model": model, "messages": messages, "stream": False}, timeout=120)
    r.raise_for_status()
    data = r.json()
    return data.get("message", {}).get("content", "")

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/chat")
def chat(req: ChatReq):
    system_base = (
        "Você é a 'chegada'. Seja direto, técnico e honesto. "
        "Formato: Contexto → Solução → Exemplo/Código → Checklist."
    )
    manifesto = (
        "Nunca invente. Se ambíguo, assuma e entregue uma primeira versão funcional. "
        "Priorize Git, testes e reprodutibilidade."
    )
    sys = {"role": "system", "content": f"{system_base}\n\n{manifesto}"}
    msgs = [sys] + req.history + [{"role": "user", "content": req.message}]
    model = DEV_MODEL if req.agent == "dev_fullstack" else REFLEX_MODEL
    out = ollama_chat(model, msgs)
    return {"reply": out}

@app.post("/ingest")
def ingest(path: str = Body(default="data/docs")):
    import glob
    files = [f for f in glob.glob(f"{path}/**/*", recursive=True) if any(f.endswith(ext) for ext in [".md",".txt",".html"])]
    return {"ingested": len(files)}
